package com.androidadvance.drooble.view.signin;

import android.content.Context;
import android.text.TextUtils;
import com.androidadvance.drooble.BaseApplication;
import com.androidadvance.drooble.R;
import com.androidadvance.drooble.data.remote.APIService;
import com.androidadvance.drooble.model.user.UserDetails;
import com.androidadvance.drooble.presenter.Presenter;
import com.socks.library.KLog;
import javax.inject.Inject;
import retrofit2.adapter.rxjava.HttpException;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

public class SignInPresenter implements Presenter<SignInMvpView> {

  private final Context mContext;

  @Inject public SignInPresenter(Context ctx) {
    ((BaseApplication) ctx.getApplicationContext()).getApplicationComponent().inject(this);
    mContext = ctx;
  }

  @Inject APIService apiService;

  private SignInMvpView signInMvpView;
  private Subscription subscription;
  private UserDetails userDetails;

  @Override public void attachView(SignInMvpView view) {
    this.signInMvpView = view;
  }

  @Override public void detachView() {
    this.signInMvpView = null;
    if (subscription != null) subscription.unsubscribe();
  }

  public void attemptSingIn(String email, String password) {

    //------ pre-validate email and password -------
    if (!validate_email_and_password(email, password)) {
      return;
    }

    signInMvpView.showProgress();
    if (subscription != null) subscription.unsubscribe();

    BaseApplication baseApplication = BaseApplication.get(signInMvpView.getContext());

    subscription = apiService.signin(email, password).observeOn(AndroidSchedulers.mainThread()).subscribeOn(baseApplication.getSubscribeScheduler()).subscribe(new Subscriber<UserDetails>() {
      @Override public void onCompleted() {
        KLog.i("User details > " + userDetails);
        signInMvpView.displayUserDetails(userDetails);
        signInMvpView.hideProgress();
      }

      @Override public void onError(Throwable error) {
        KLog.e("Error signin in: ", error);
        if (isHttp404(error)) {
          signInMvpView.showErrorMessage(baseApplication.getString(R.string.dialog_general_error_message));
        } else {
          if (isHttp400(error)) {
            signInMvpView.showErrorMessage(baseApplication.getString(R.string.incorrect_username_or_password));
          } else {
            signInMvpView.showErrorMessage(baseApplication.getString(R.string.dialog_general_error_message));
          }
        }
        signInMvpView.hideProgress();
      }

      @Override public void onNext(UserDetails userDetails) {
        SignInPresenter.this.userDetails = userDetails;
      }
    });
  }

  private boolean validate_email_and_password(String email, String password) {

    if (email.length() < 4) {
      signInMvpView.showErrorMessage(mContext.getString(R.string.invalid_email));
      return false;
    }

    if (password.length() < 5) {
      signInMvpView.showErrorMessage(mContext.getString(R.string.empty_password));
      return false;
    }

    if (!isValidEmail(email)) {
      signInMvpView.showErrorMessage(mContext.getString(R.string.invalid_email));
      return false;
    }

    return true;
  }

  private static boolean isHttp404(Throwable error) {
    return error instanceof HttpException && ((HttpException) error).code() == 404;
  }

  private static boolean isHttp400(Throwable error) {
    return error instanceof HttpException && ((HttpException) error).code() == 400;
  }

  public final static boolean isValidEmail(CharSequence target) {
    if (TextUtils.isEmpty(target)) {
      return false;
    } else {
      return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
  }
}