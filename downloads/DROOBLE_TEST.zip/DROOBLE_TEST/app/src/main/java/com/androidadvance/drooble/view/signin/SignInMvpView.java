package com.androidadvance.drooble.view.signin;

import com.androidadvance.drooble.model.user.UserDetails;
import com.androidadvance.drooble.view.MvpView;

public interface SignInMvpView extends MvpView {

  void showErrorMessage(String message);

  void showInfoMessage(String message);

  void displayUserDetails(UserDetails userDetails);

  void showProgress();

  void hideProgress();
}