package com.androidadvance.drooble.events;

public class AuthenticationErrorEvent {
  public AuthenticationErrorEvent() {
  }
}
