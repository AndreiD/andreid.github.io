package com.androidadvance.drooble.view.userdetails;

import android.animation.Animator;
import android.annotation.TargetApi;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.androidadvance.drooble.R;
import com.androidadvance.drooble.model.user.UserDetails;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.socks.library.KLog;
import com.squareup.picasso.Picasso;

public class UserDialogFragment extends DialogFragment {

  private static final String ARG_USER_DETAILS = "ARG_USER_DETAILS";
  private UserDetails userDetails;
  private RelativeLayout relative_layout_userdetails_dialog;
  private CircularImageView imageView_fragment_details_profile_pic;

  public UserDialogFragment() {
  }

  public static UserDialogFragment newInstance(UserDetails userDetails) {
    UserDialogFragment userDialogFragment = new UserDialogFragment();
    Bundle args = new Bundle();
    args.putSerializable(ARG_USER_DETAILS, userDetails);
    userDialogFragment.setArguments(args);

    return userDialogFragment;
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    userDetails = (UserDetails) getArguments().getSerializable(ARG_USER_DETAILS);
  }

  @Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_detail, container);
  }

  @Override public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    TextView textView_fragment_details_about = (TextView) view.findViewById(R.id.textView_fragment_details_about);
    TextView textView_fragment_details_fullname = (TextView) view.findViewById(R.id.textView_fragment_details_fullname);
    relative_layout_userdetails_dialog = (RelativeLayout) view.findViewById(R.id.relative_layout_userdetails_dialog);

    setup_style_and_animations();

    imageView_fragment_details_profile_pic = (CircularImageView) view.findViewById(R.id.imageView_fragment_details_profile_pic);
    textView_fragment_details_about.setMovementMethod(new ScrollingMovementMethod());

    textView_fragment_details_fullname.setText(userDetails.fullname);
    textView_fragment_details_about.setText(userDetails.aboutMe);
    Picasso.with(getActivity()).load(userDetails.avatar).into(imageView_fragment_details_profile_pic);
  }

  private void setup_style_and_animations() {

    getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(0));  //dark outside background
    getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE); //show no title. for android 14...

    //if it's lollipop show a circular reveal.
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
      KLog.d("animations", " >= lollipop triggered!");

      relative_layout_userdetails_dialog.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
        @TargetApi(Build.VERSION_CODES.LOLLIPOP) @Override public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
          v.removeOnLayoutChangeListener(this);

          relative_layout_userdetails_dialog.setVisibility(View.INVISIBLE);
          int cx = relative_layout_userdetails_dialog.getMeasuredWidth() / 2;
          int cy = relative_layout_userdetails_dialog.getMeasuredHeight() / 2;
          int finalRadius = Math.max(relative_layout_userdetails_dialog.getWidth(), relative_layout_userdetails_dialog.getHeight());
          Animator animator = ViewAnimationUtils.createCircularReveal(relative_layout_userdetails_dialog, cx, cy, 0, finalRadius);
          animator.setInterpolator(new LinearInterpolator());
          animator.setDuration(700);
          relative_layout_userdetails_dialog.setVisibility(View.VISIBLE);
          animator.start();
        }
      });
    } else {
      KLog.d("animations", " NO lollipop animations triggered!");
      getDialog().getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
    }
  }
}
