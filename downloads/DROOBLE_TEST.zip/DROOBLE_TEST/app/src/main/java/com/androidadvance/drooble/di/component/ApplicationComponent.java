package com.androidadvance.drooble.di.component;

import com.androidadvance.drooble.BaseApplication;
import com.androidadvance.drooble.data.remote.APIService;
import com.androidadvance.drooble.di.module.ApplicationModule;
import com.androidadvance.drooble.view.signin.SignInPresenter;
import dagger.Component;
import javax.inject.Singleton;

@Singleton
@Component(modules = { ApplicationModule.class })
public interface ApplicationComponent {

  void inject(SignInPresenter signInPresenter);

  void inject(BaseApplication baseApplication);

  APIService apiService();
}