package com.androidadvance.drooble.model.user;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class UserDetails implements Serializable {

  private static final long serialVersionUID = 3657773293974543890L;

  @SerializedName("aboutMe") public String aboutMe;

  @SerializedName("avatar") public String avatar;

  @SerializedName("fullname") public String fullname;

  @Override public String toString() {
    return "UserDetails{" +
        "aboutMe='" + aboutMe + '\'' +
        ", avatar='" + avatar + '\'' +
        ", fullname='" + fullname + '\'' +
        '}';
  }
}
