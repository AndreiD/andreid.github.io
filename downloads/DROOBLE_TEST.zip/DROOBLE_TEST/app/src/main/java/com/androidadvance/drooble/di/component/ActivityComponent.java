package com.androidadvance.drooble.di.component;

import com.androidadvance.drooble.di.ActivityScope;
import com.androidadvance.drooble.view.signin.SignInActivity;
import dagger.Component;

@ActivityScope
@Component(dependencies = ApplicationComponent.class)
public interface ActivityComponent extends ApplicationComponent {

  void inject(SignInActivity signInActivity);

}