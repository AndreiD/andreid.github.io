package com.androidadvance.drooble;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.support.annotation.VisibleForTesting;
import com.androidadvance.drooble.di.component.ApplicationComponent;
import com.androidadvance.drooble.di.component.DaggerApplicationComponent;
import com.androidadvance.drooble.di.module.ApplicationModule;
import com.socks.library.KLog;
import rx.Scheduler;
import rx.schedulers.Schedulers;

public class BaseApplication extends Application {

  private Scheduler defaultSubscribeScheduler;
  private ApplicationComponent applicationComponent;


  @Override public void onCreate() {
    super.onCreate();

    boolean isDebuggable = (0 != (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE));

    if (isDebuggable) {
      KLog.init(true);
    } else {
      KLog.init(false);
    }

    applicationComponent = DaggerApplicationComponent.builder().applicationModule(new ApplicationModule(this)).build();

    applicationComponent.inject(this);

  }

  public static BaseApplication get(Context context) {
    return (BaseApplication) context.getApplicationContext();
  }

  public ApplicationComponent getApplicationComponent() {
    return applicationComponent;
  }

  @VisibleForTesting public void setApplicationComponent(ApplicationComponent applicationComponent) {
    applicationComponent = applicationComponent;
  }

  public Scheduler getSubscribeScheduler() {
    if (defaultSubscribeScheduler == null) {
      defaultSubscribeScheduler = Schedulers.io();
    }
    return defaultSubscribeScheduler;
  }

  @Override public void onLowMemory() {
    super.onLowMemory();
    KLog.e("########## onLowMemory ##########");
  }
}
