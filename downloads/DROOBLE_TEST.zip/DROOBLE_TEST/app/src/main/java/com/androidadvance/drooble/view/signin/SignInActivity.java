package com.androidadvance.drooble.view.signin;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.FragmentManager;
import android.transition.TransitionInflater;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.androidadvance.drooble.R;
import com.androidadvance.drooble.model.user.UserDetails;
import com.androidadvance.drooble.util.DialogFactory;
import com.androidadvance.drooble.view.BaseActivity;
import com.androidadvance.drooble.view.userdetails.UserDialogFragment;
import javax.inject.Inject;

public class SignInActivity extends BaseActivity implements SignInMvpView {

  @Bind(R.id.button_login_forgot) Button button_login_forgot;
  @Bind(R.id.button_forgot_password_back_to_login) Button button_forgot_password_back_to_login;
  @Bind(R.id.input_username) EditText input_username;
  @Bind(R.id.input_password) EditText input_password;
  @Bind(R.id.input_layout_password) TextInputLayout input_layout_password;
  @Bind(R.id.relative_layout_parent) RelativeLayout relative_layout_parent;
  @Bind(R.id.imageView_logo) ImageView imageView_logo;
  @Bind(R.id.linear_layout_controls) LinearLayout linearLayout_controls;
  private static ProgressBar mProgressBar = null;
  private SignInPresenter presenter;
  private boolean login_mode_active = true;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getComponent().inject(this);
    setContentView(R.layout.activity_signin);
    ButterKnife.bind(this);

    animation_on_enter_screen();

    presenter = new SignInPresenter(this);
    presenter.attachView(this);
  }

  private void animation_on_enter_screen() {
    imageView_logo.setVisibility(View.INVISIBLE);
    linearLayout_controls.setVisibility(View.INVISIBLE);
    Animation zoominAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.bounce_anim);
    imageView_logo.startAnimation(zoominAnim);
    imageView_logo.setVisibility(View.VISIBLE);

    new CountDownTimer(2000, 2000) {
      @Override public void onTick(long millisUntilFinished) {
      }

      @Override public void onFinish() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {

          int cx = linearLayout_controls.getMeasuredWidth() / 2;
          int cy = linearLayout_controls.getMeasuredHeight() / 2;
          int finalRadius = Math.max(linearLayout_controls.getWidth(), linearLayout_controls.getHeight());

          Animator animator = ViewAnimationUtils.createCircularReveal(linearLayout_controls, cx, cy, 0, finalRadius);
          animator.setInterpolator(new LinearInterpolator());
          animator.setDuration(2000);
          linearLayout_controls.setVisibility(View.VISIBLE);
          animator.start();
        } else {

          Animation zoomOutAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
          linearLayout_controls.startAnimation(zoomOutAnimation);
          linearLayout_controls.setVisibility(View.VISIBLE);
        }
      }
    }.start();
  }

  @OnClick(R.id.button_login_forgot) void onClick_login_forgot() {
    if (!login_mode_active) {
      showErrorMessage("not done...");
      return;
    }

    presenter.attemptSingIn(input_username.getText().toString().trim(), input_password.getText().toString());
  }

  @OnClick(R.id.button_forgot_password_back_to_login) void onClick_forgot_password() {

    //------ it will animate to the position of the input_username
    int[] viewLocation = new int[2];
    input_layout_password.getLocationInWindow(viewLocation);

    if (login_mode_active) {
      login_mode_active = false;
      button_login_forgot.setText(getString(R.string.reset));
      button_forgot_password_back_to_login.setText(getString(R.string.back_to_login));

      //------- moves the button up

      ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(button_login_forgot, "translationY", 0, -viewLocation[0] - 50);
      objectAnimator.setDuration(700);
      objectAnimator.setInterpolator(new LinearInterpolator());
      objectAnimator.start();

      //------- fade out the password field
      input_password.animate().translationY(0).setDuration(300).alpha(0.0f).setListener(new AnimatorListenerAdapter() {
        @Override public void onAnimationEnd(Animator animation) {
          super.onAnimationEnd(animation);
          input_password.setVisibility(View.INVISIBLE);
        }
      });

      input_layout_password.animate().translationY(0).setDuration(300).alpha(0.0f).setListener(new AnimatorListenerAdapter() {
        @Override public void onAnimationEnd(Animator animation) {
          super.onAnimationEnd(animation);
          input_layout_password.setVisibility(View.INVISIBLE);
        }
      });
    } else {
      login_mode_active = true;
      button_login_forgot.setText(getString(R.string.login));
      button_forgot_password_back_to_login.setText(getString(R.string.forgot_password));
      input_password.setVisibility(View.VISIBLE);
      input_layout_password.setVisibility(View.VISIBLE);

      //------- moves the button down
      ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(button_login_forgot, "translationY", -viewLocation[0] - 50, 0);
      objectAnimator.setDuration(700);
      objectAnimator.setInterpolator(new LinearInterpolator());
      objectAnimator.start();

      input_password.animate().alpha(1.0f).setDuration(2000).setListener(new AnimatorListenerAdapter() {
        @Override public void onAnimationEnd(Animator animation) {
          super.onAnimationEnd(animation);
          input_password.setVisibility(View.VISIBLE);
        }
      });
      input_layout_password.animate().alpha(1.0f).setDuration(2000).setListener(new AnimatorListenerAdapter() {
        @Override public void onAnimationEnd(Animator animation) {
          super.onAnimationEnd(animation);
          input_layout_password.setVisibility(View.VISIBLE);
        }
      });
    }
  }

  @Override protected void onDestroy() {
    presenter.detachView();
    super.onDestroy();
  }

  @Override public void showErrorMessage(String message) {
    DialogFactory.showErrorSnackBar(SignInActivity.this, findViewById(android.R.id.content), message).show();
  }

  @Override public void showInfoMessage(String message) {
    DialogFactory.showInfoSnackBar(SignInActivity.this, findViewById(android.R.id.content), message).show();
  }

  @Override public void displayUserDetails(UserDetails userDetails) {
    FragmentManager fm = getSupportFragmentManager();
    UserDialogFragment userDialogFragment = UserDialogFragment.newInstance(userDetails);
    userDialogFragment.show(fm, "user_details_fragment");
  }

  @Override public void showProgress() {
    if (mProgressBar == null) {
      mProgressBar = DialogFactory.DProgressBar(SignInActivity.this);
    } else {
      mProgressBar.setVisibility(View.VISIBLE);
    }
  }

  @Override public void hideProgress() {
    mProgressBar.setVisibility(View.GONE);
  }

  @Override public Context getContext() {
    return this;
  }
}
