package com.androidadvance.drooble.data.remote;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import com.androidadvance.drooble.model.user.UserDetails;
import java.util.concurrent.TimeUnit;
import okhttp3.Cache;
import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface APIService {

  String ENDPOINT = "https://www.youlocalapp.com/oauth2/2.0/";

  @FormUrlEncoded @POST("signin") Observable<UserDetails> signin(@Field("email") String email, @Field("password") String password);

  class Factory {

    public static APIService create(Context context) {

      OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
      builder.readTimeout(15, TimeUnit.SECONDS);
      builder.connectTimeout(10, TimeUnit.SECONDS);
      builder.writeTimeout(10, TimeUnit.SECONDS);
      
      builder.certificatePinner(new CertificatePinner.Builder().add("*.youlocalapp.com", "sha256/RqzElicVPA6LkKm9HblOvNOUqWmD+4zNXcRb+WjcaAE=")
          .add("*.youlocalapp.com", "sha256/8Rw90Ej3Ttt8RRkrg+WYDS9n7IS03bk5bjP/UXPtaY8=")
          .add("*.youlocalapp.com", "sha256/Ko8tivDrEjiY90yGasP6ZpBU4jwXvHqVvQI0GS3GNdA=")
          .add("*.youlocalapp.com", "sha256/VjLZe/p3W/PJnd6lL8JVNBCGQBZynFLdZSTIqcO0SJ8=")
          .build());

      boolean isDebuggable = (0 != (context.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE));
      if (isDebuggable) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
        builder.addInterceptor(interceptor);
      }
      int cacheSize = 10 * 1024 * 1024; // 10 MiB
      Cache cache = new Cache(context.getCacheDir(), cacheSize);
      builder.cache(cache);
      OkHttpClient client = builder.build();

      Retrofit retrofit =
          new Retrofit.Builder().baseUrl(APIService.ENDPOINT).client(client).addConverterFactory(GsonConverterFactory.create()).addCallAdapterFactory(RxJavaCallAdapterFactory.create()).build();

      return retrofit.create(APIService.class);
    }
  }
}