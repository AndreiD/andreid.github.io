package com.androidadvance.drooble.view;

import android.content.Context;

public interface MvpView {
  Context getContext();
}