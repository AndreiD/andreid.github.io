package com.androidadvance.drooble.di.module;

import com.androidadvance.drooble.BaseApplication;
import com.androidadvance.drooble.data.remote.APIService;
import dagger.Module;
import dagger.Provides;
import javax.inject.Singleton;

@Module
public class ApplicationModule {

  private final BaseApplication baseApplicaton;

  public ApplicationModule(BaseApplication baseApplication) {
    this.baseApplicaton = baseApplication;
  }

  @Provides @Singleton public BaseApplication provideApplication() {
    return baseApplicaton;
  }

  @Provides @Singleton public APIService provideApiService() {
    return APIService.Factory.create(baseApplicaton);
  }

}