package com.androidadvance.drooble;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import com.androidadvance.drooble.data.remote.APIService;
import com.androidadvance.drooble.model.user.UserDetails;
import com.androidadvance.drooble.view.signin.SignInActivity;
import com.socks.library.KLog;
import javax.inject.Inject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static android.support.test.InstrumentationRegistry.getTargetContext;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.clearText;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class SignInActivityTest {

  @Rule public ActivityTestRule<SignInActivity> activityTestRule = new ActivityTestRule<>(SignInActivity.class);

  @Inject APIService apiService;

  @Before public void setUp() {
    apiService = ((BaseApplication) activityTestRule.getActivity().getApplication()).getApplicationComponent().apiService();
    //------ wait for the animations to finish...
    try {
      Thread.sleep(5000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test public void api_working_ok() {

    apiService.signin("androidtestuser@youloc.al", "android").observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.newThread()).subscribe(new Subscriber<UserDetails>() {
      public UserDetails userDetails;

      @Override public void onCompleted() {
        KLog.d(">>>" + userDetails.fullname);
        assertThat(userDetails.fullname, is("AndroidUser"));
      }

      @Override public void onError(Throwable error) {
        KLog.e("Error signin in: ", error);
        throw new RuntimeException("wrong test username/password ?");
      }

      @Override public void onNext(UserDetails userDetails) {
        this.userDetails = userDetails;
      }
    });
  }

  @Test public void visual_empty_password() {

    onView(withId(R.id.input_username)).perform(clearText(), typeText("fdkslj@gofjfds.com"));
    onView(withId(R.id.input_password)).perform(clearText());
    onView(withId(R.id.button_login_forgot)).perform(click());
    onView(allOf(withId(android.support.design.R.id.snackbar_text), withText(getTargetContext().getString(R.string.empty_password)))).check(matches(isDisplayed()));
  }

  @Test public void visual_correct_email() {

    onView(withId(R.id.input_username)).perform(clearText(), typeText("fdkslj"));
    onView(withId(R.id.input_password)).perform(clearText(), typeText("fdskslj"));
    onView(withId(R.id.button_login_forgot)).perform(click());
    onView(allOf(withId(android.support.design.R.id.snackbar_text), withText(getTargetContext().getString(R.string.invalid_email)))).check(matches(isDisplayed()));
  }

  @Test public void visual_show_reset_button() {

    onView(withId(R.id.button_forgot_password_back_to_login)).perform(click());
    onView(withId(R.id.button_login_forgot)).check(matches(withText(getTargetContext().getString(R.string.reset))));
  }

  @Test public void display_dialog_on_successful_login() {

    onView(withId(R.id.input_username)).perform(clearText(), typeText("androidtestuser@youloc.al"));
    onView(withId(R.id.input_password)).perform(clearText(), typeText("android"));
    onView(withId(R.id.button_login_forgot)).perform(click());

    onView(withId(R.id.textView_fragment_details_fullname)).check(matches(allOf(withText("AndroidUser"), isDisplayed())));
  }
}